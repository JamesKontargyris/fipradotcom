<?php
/**
 * @author Olexandr Zanichkovsky <olexandr.zanichkovsky@zophiatech.com>
 * @package AST
 */

/**
 * Represents a statement
 *
 * @abstract
 */
abstract class XmlImportAstStatement
{
  
}